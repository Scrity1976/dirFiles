const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const port = 80;

app.get("/movies/:id", (req, res) => {
    // Get video path
    const videoPath = path.join(__dirname, `Movies/${req.params.id}`);

    // Ensure there is a range given for the video
    const range = req.headers.range;
    if (!range) {
        res.download(videoPath);
        return;
    }

    // Get video stats
    const videoSize = fs.statSync(videoPath).size;

    // Parse Range
    // Example: "bytes=32324-"
    const CHUNK_SIZE = 10 ** 6; // 1MB
    const start = Number(range.replace(/\D/g, ""));
    const end = Math.min(start + CHUNK_SIZE, videoSize - 1);

    // Create headers
    const contentLength = end - start + 1;
    const headers = {
        "Content-Range": `bytes ${start}-${end}/${videoSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": contentLength,
        "Content-Type": "video/mp4"
    };

    // HTTP Status 206 for Partial Content
    res.writeHead(206, headers);

    // Create video read stream for this particular chunk
    const videoStream = fs.createReadStream(videoPath, { start, end });

    // Stream the video chunk to the client
    videoStream.pipe(res);
});

app.listen(port, () => {
    console.log("App listening on port:", port);
});
