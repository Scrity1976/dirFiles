const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const port = 80;

app.get("/Movies/:id", (req, res) => {
    // Get video path
    const videoPath = path.join(__dirname, `Movies/${req.params.id}`);

    if (!fs.existsSync(videoPath)) {
        return res.status(403).send("You do not have permission to access this page.");
    }

    // Ensure there is a range given for the video,
    // download otherwise.
    const range = req.headers.range;
    if (!range) {
        return res.download(videoPath);
    }

    // Get video stats
    const videoSize = fs.statSync(videoPath).size;

    // Parse Range
    // Example: "bytes=32324-"
    const parts = range.replace(/bytes=/, "").split("-");
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : videoSize - 1;

    // Create headers
    const contentLength = end - start + 1;
    const headers = {
        "Content-Range": `bytes ${start}-${end}/${videoSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": contentLength,
        "Content-Type": "video/mp4"
    };

    // HTTP Status 206 for Partial Content
    res.writeHead(206, headers);

    // Create video read stream for this particular chunk
    const videoStream = fs.createReadStream(videoPath, { start, end });

    // Stream the video chunk to the client
    videoStream.pipe(res);
});

app.listen(port, () => {
    console.log("App listening on port:", port);
});
