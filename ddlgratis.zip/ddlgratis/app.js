const express = require("express");
const compression = require("compression");
const helmet = require("helmet");
const path = require("path");

const app = express();
const port = 80;

// Use gzip compression and security patch
app.use(compression());
app.use(helmet());

// Initialize public directory
app.use("/movies", express.static(path.join(__dirname, "Movies")));

// Support parsing of application/json type post data
app.use(express.json());

app.listen(port, () => {
    console.log("The server is running on port", port);
});
